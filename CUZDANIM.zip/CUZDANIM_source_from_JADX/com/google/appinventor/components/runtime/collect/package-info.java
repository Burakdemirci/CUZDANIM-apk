package com.google.appinventor.components.runtime.collect;

interface package-info {
}
