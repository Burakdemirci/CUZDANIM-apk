package com.google.appinventor.components.runtime;

public interface OnPauseListener {
    void onPause();
}
