package com.google.appinventor.components.runtime;

public interface Deleteable {
    void onDelete();
}
