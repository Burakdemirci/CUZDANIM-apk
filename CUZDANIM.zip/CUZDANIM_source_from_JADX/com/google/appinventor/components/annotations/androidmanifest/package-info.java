package com.google.appinventor.components.annotations.androidmanifest;

interface package-info {
}
