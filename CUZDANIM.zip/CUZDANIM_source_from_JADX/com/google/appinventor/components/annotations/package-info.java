package com.google.appinventor.components.annotations;

interface package-info {
}
