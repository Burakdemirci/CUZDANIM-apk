package com.google.appinventor.common.version;

interface package-info {
}
