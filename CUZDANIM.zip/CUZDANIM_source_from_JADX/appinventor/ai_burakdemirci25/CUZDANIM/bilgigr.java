package appinventor.ai_burakdemirci25.CUZDANIM;

import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Camera;
import com.google.appinventor.components.runtime.Canvas;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TableArrangement;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.TinyDB;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.FullScreenVideoUtil;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.expr.SetExp;
import gnu.kawa.functions.AddOp;
import gnu.kawa.functions.ArithOp;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.ParseFormat;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.kawa.xml.ElementType;
import gnu.kawa.xml.XDataType;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.Sequence;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.Procedure;
import gnu.mapping.PropertySet;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.DFloNum;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import kawa.standard.require;

/* compiled from: bilgigr.yail */
public class bilgigr extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final SimpleSymbol Lit100;
    static final FString Lit101;
    static final FString Lit102;
    static final SimpleSymbol Lit103;
    static final FString Lit104;
    static final SimpleSymbol Lit105;
    static final FString Lit106;
    static final SimpleSymbol Lit107;
    static final FString Lit108;
    static final FString Lit109;
    static final SimpleSymbol Lit11;
    static final SimpleSymbol Lit110;
    static final FString Lit111;
    static final FString Lit112;
    static final SimpleSymbol Lit113;
    static final SimpleSymbol Lit114;
    static final IntNum Lit115;
    static final SimpleSymbol Lit116;
    static final DFloNum Lit117;
    static final SimpleSymbol Lit118;
    static final IntNum Lit119;
    static final SimpleSymbol Lit12;
    static final FString Lit120;
    static final FString Lit121;
    static final SimpleSymbol Lit122;
    static final SimpleSymbol Lit123;
    static final FString Lit124;
    static final SimpleSymbol Lit125;
    static final SimpleSymbol Lit126;
    static final SimpleSymbol Lit127;
    static final FString Lit128;
    static final SimpleSymbol Lit129;
    static final SimpleSymbol Lit13;
    static final IntNum Lit130;
    static final FString Lit131;
    static final FString Lit132;
    static final SimpleSymbol Lit133;
    static final FString Lit134;
    static final FString Lit135;
    static final SimpleSymbol Lit136;
    static final IntNum Lit137;
    static final DFloNum Lit138;
    static final IntNum Lit139;
    static final PairWithPosition Lit14;
    static final FString Lit140;
    static final FString Lit141;
    static final SimpleSymbol Lit142;
    static final IntNum Lit143;
    static final FString Lit144;
    static final SimpleSymbol Lit145;
    static final SimpleSymbol Lit146;
    static final PairWithPosition Lit147;
    static final SimpleSymbol Lit148;
    static final FString Lit149;
    static final SimpleSymbol Lit15;
    static final IntNum Lit150;
    static final IntNum Lit151;
    static final SimpleSymbol Lit152;
    static final FString Lit153;
    static final FString Lit154;
    static final FString Lit155;
    static final FString Lit156;
    static final FString Lit157;
    static final SimpleSymbol Lit158;
    static final PairWithPosition Lit159;
    static final SimpleSymbol Lit16;
    static final SimpleSymbol Lit160;
    static final SimpleSymbol Lit161;
    static final SimpleSymbol Lit162;
    static final SimpleSymbol Lit163;
    static final SimpleSymbol Lit164;
    static final SimpleSymbol Lit165;
    static final SimpleSymbol Lit166;
    static final SimpleSymbol Lit167;
    static final SimpleSymbol Lit168;
    static final SimpleSymbol Lit169;
    static final FString Lit17;
    static final SimpleSymbol Lit170;
    static final SimpleSymbol Lit171;
    static final SimpleSymbol Lit172;
    static final SimpleSymbol Lit173;
    static final SimpleSymbol Lit174;
    static final SimpleSymbol Lit18;
    static final SimpleSymbol Lit19;
    static final SimpleSymbol Lit2;
    static final IntNum Lit20;
    static final SimpleSymbol Lit21;
    static final SimpleSymbol Lit22;
    static final IntNum Lit23;
    static final FString Lit24;
    static final FString Lit25;
    static final SimpleSymbol Lit26;
    static final SimpleSymbol Lit27;
    static final IntNum Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final FString Lit31;
    static final FString Lit32;
    static final IntNum Lit33;
    static final SimpleSymbol Lit34;
    static final SimpleSymbol Lit35;
    static final SimpleSymbol Lit36;
    static final FString Lit37;
    static final FString Lit38;
    static final SimpleSymbol Lit39;
    static final SimpleSymbol Lit4;
    static final FString Lit40;
    static final FString Lit41;
    static final SimpleSymbol Lit42;
    static final FString Lit43;
    static final FString Lit44;
    static final SimpleSymbol Lit45;
    static final FString Lit46;
    static final FString Lit47;
    static final SimpleSymbol Lit48;
    static final FString Lit49;
    static final SimpleSymbol Lit5;
    static final FString Lit50;
    static final SimpleSymbol Lit51;
    static final FString Lit52;
    static final FString Lit53;
    static final SimpleSymbol Lit54;
    static final FString Lit55;
    static final FString Lit56;
    static final SimpleSymbol Lit57;
    static final FString Lit58;
    static final FString Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final FString Lit61;
    static final FString Lit62;
    static final SimpleSymbol Lit63;
    static final FString Lit64;
    static final FString Lit65;
    static final SimpleSymbol Lit66;
    static final FString Lit67;
    static final FString Lit68;
    static final SimpleSymbol Lit69;
    static final SimpleSymbol Lit7;
    static final FString Lit70;
    static final FString Lit71;
    static final SimpleSymbol Lit72;
    static final FString Lit73;
    static final FString Lit74;
    static final SimpleSymbol Lit75;
    static final IntNum Lit76;
    static final FString Lit77;
    static final FString Lit78;
    static final SimpleSymbol Lit79;
    static final SimpleSymbol Lit8;
    static final IntNum Lit80;
    static final SimpleSymbol Lit81;
    static final FString Lit82;
    static final PairWithPosition Lit83;
    static final PairWithPosition Lit84;
    static final PairWithPosition Lit85;
    static final PairWithPosition Lit86;
    static final SimpleSymbol Lit87;
    static final PairWithPosition Lit88;
    static final PairWithPosition Lit89;
    static final SimpleSymbol Lit9;
    static final PairWithPosition Lit90;
    static final PairWithPosition Lit91;
    static final PairWithPosition Lit92;
    static final SimpleSymbol Lit93;
    static final SimpleSymbol Lit94;
    static final FString Lit95;
    static final SimpleSymbol Lit96;
    static final IntNum Lit97;
    static final FString Lit98;
    static final FString Lit99;
    public static bilgigr bilgigr;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn31 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn33 = null;
    static final ModuleMethod lambda$Fn34 = null;
    static final ModuleMethod lambda$Fn35 = null;
    static final ModuleMethod lambda$Fn36 = null;
    static final ModuleMethod lambda$Fn37 = null;
    static final ModuleMethod lambda$Fn38 = null;
    static final ModuleMethod lambda$Fn39 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn40 = null;
    static final ModuleMethod lambda$Fn41 = null;
    static final ModuleMethod lambda$Fn42 = null;
    static final ModuleMethod lambda$Fn43 = null;
    static final ModuleMethod lambda$Fn44 = null;
    static final ModuleMethod lambda$Fn45 = null;
    static final ModuleMethod lambda$Fn46 = null;
    static final ModuleMethod lambda$Fn47 = null;
    static final ModuleMethod lambda$Fn48 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public TextBox AYLIKTX;
    public Label AylikLB;
    public Camera Camera1;
    public final ModuleMethod Camera1$AfterPicture;
    public Label DigerLB;
    public TextBox DigerTX;
    public Button FOTOBUTON;
    public final ModuleMethod FOTOBUTON$Click;
    public Label FaturalarLB;
    public TextBox FaturalarTX;
    public Canvas FisCanvas;
    public Button FisGorBTN;
    public final ModuleMethod FisGorBTN$Click;
    public Label FisGorLB;
    public Label FisLB;
    public Button GeriBTN;
    public final ModuleMethod GeriBTN$Click;
    public HorizontalArrangement HorizontalArrangement1;
    public HorizontalArrangement HorizontalArrangement2;
    public HorizontalArrangement HorizontalArrangement3;
    public HorizontalArrangement HorizontalArrangement4;
    public HorizontalArrangement HorizontalArrangement5;
    public Label KiraLB;
    public TextBox KiraTX;
    public Label Label1;
    public Label Label2;
    public Button OnayaBTN;
    public final ModuleMethod OnayaBTN$Click;
    public TextBox ResultTX;
    public TableArrangement TableArrangement1;
    public TableArrangement TableArrangement2;
    public Label TaksitLB;
    public TextBox TaksitTX;
    public TinyDB TinyDB1;
    public VerticalArrangement VerticalArrangement1;
    public VerticalArrangement VerticalArrangement2;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public final ModuleMethod bilgigr$Initialize;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    /* compiled from: bilgigr.yail */
    public class frame extends ModuleBody {
        bilgigr $main;

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            switch (moduleMethod.selector) {
                case ParseFormat.SEEN_MINUS /*1*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.DIVIDE_INEXACT /*5*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.ASHIFT_LEFT /*10*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.ASHIFT_RIGHT /*11*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.LSHIFT_RIGHT /*12*/:
                    if (!(obj instanceof bilgigr)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case 69:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod, obj, callContext);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            switch (moduleMethod.selector) {
                case SetExp.DEFINING_FLAG /*2*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.QUOTIENT /*6*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.QUOTIENT_EXACT /*7*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.ASHIFT_GENERAL /*9*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.IOR /*14*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod, obj, obj2, callContext);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            switch (moduleMethod.selector) {
                case SetExp.PREFER_BINDING2 /*8*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.value3 = obj3;
                    callContext.value4 = obj4;
                    callContext.proc = moduleMethod;
                    callContext.pc = 4;
                    return 0;
                case ArithOp.AND /*13*/:
                    if (!(obj instanceof bilgigr)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    if (!(obj2 instanceof Component)) {
                        return -786430;
                    }
                    callContext.value2 = obj2;
                    if (!(obj3 instanceof String)) {
                        return -786429;
                    }
                    callContext.value3 = obj3;
                    if (!(obj4 instanceof String)) {
                        return -786428;
                    }
                    callContext.value4 = obj4;
                    callContext.proc = moduleMethod;
                    callContext.pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod, obj, obj2, obj3, obj4, callContext);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            switch (moduleMethod.selector) {
                case ParseFormat.SEEN_MINUS /*1*/:
                    this.$main.androidLogForm(obj);
                    return Values.empty;
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj);
                    } catch (ClassCastException e) {
                        throw new WrongType(e, "lookup-in-form-environment", 1, obj);
                    }
                case ArithOp.DIVIDE_INEXACT /*5*/:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        throw new WrongType(e2, "is-bound-in-form-environment", 1, obj);
                    }
                case ArithOp.ASHIFT_LEFT /*10*/:
                    this.$main.addToFormDoAfterCreation(obj);
                    return Values.empty;
                case ArithOp.ASHIFT_RIGHT /*11*/:
                    this.$main.sendError(obj);
                    return Values.empty;
                case ArithOp.LSHIFT_RIGHT /*12*/:
                    this.$main.processException(obj);
                    return Values.empty;
                case 69:
                    return this.$main.Camera1$AfterPicture(obj);
                default:
                    return super.apply1(moduleMethod, obj);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            switch (moduleMethod.selector) {
                case SetExp.PREFER_BINDING2 /*8*/:
                    this.$main.addToComponents(obj, obj2, obj3, obj4);
                    return Values.empty;
                case ArithOp.AND /*13*/:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj, (String) obj2, (String) obj3, (Object[]) obj4) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    throw new WrongType(e, "dispatchEvent", 4, obj4);
                                }
                            } catch (ClassCastException e2) {
                                throw new WrongType(e2, "dispatchEvent", 3, obj3);
                            }
                        } catch (ClassCastException e22) {
                            throw new WrongType(e22, "dispatchEvent", 2, obj2);
                        }
                    } catch (ClassCastException e222) {
                        throw new WrongType(e222, "dispatchEvent", 1, obj);
                    }
                default:
                    return super.apply4(moduleMethod, obj, obj2, obj3, obj4);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            switch (moduleMethod.selector) {
                case SetExp.DEFINING_FLAG /*2*/:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj, obj2);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        throw new WrongType(e, "add-to-form-environment", 1, obj);
                    }
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj, obj2);
                    } catch (ClassCastException e2) {
                        throw new WrongType(e2, "lookup-in-form-environment", 1, obj);
                    }
                case ArithOp.QUOTIENT /*6*/:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj, obj2);
                        return Values.empty;
                    } catch (ClassCastException e22) {
                        throw new WrongType(e22, "add-to-global-var-environment", 1, obj);
                    }
                case ArithOp.QUOTIENT_EXACT /*7*/:
                    this.$main.addToEvents(obj, obj2);
                    return Values.empty;
                case ArithOp.ASHIFT_GENERAL /*9*/:
                    this.$main.addToGlobalVars(obj, obj2);
                    return Values.empty;
                case ArithOp.IOR /*14*/:
                    return this.$main.lookupHandler(obj, obj2);
                default:
                    return super.apply2(moduleMethod, obj, obj2);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            switch (moduleMethod.selector) {
                case ArithOp.XOR /*15*/:
                    return bilgigr.lambda2();
                case SetExp.PROCEDURE /*16*/:
                    this.$main.$define();
                    return Values.empty;
                case Sequence.INT_U8_VALUE /*17*/:
                    return bilgigr.lambda3();
                case Sequence.INT_S8_VALUE /*18*/:
                    return this.$main.bilgigr$Initialize();
                case Sequence.INT_U16_VALUE /*19*/:
                    return bilgigr.lambda4();
                case Sequence.INT_S16_VALUE /*20*/:
                    return bilgigr.lambda5();
                case Sequence.INT_U32_VALUE /*21*/:
                    return bilgigr.lambda6();
                case Sequence.INT_S32_VALUE /*22*/:
                    return bilgigr.lambda7();
                case Sequence.INT_U64_VALUE /*23*/:
                    return bilgigr.lambda8();
                case Sequence.INT_S64_VALUE /*24*/:
                    return bilgigr.lambda9();
                case Sequence.FLOAT_VALUE /*25*/:
                    return bilgigr.lambda10();
                case Sequence.DOUBLE_VALUE /*26*/:
                    return bilgigr.lambda11();
                case Sequence.BOOLEAN_VALUE /*27*/:
                    return bilgigr.lambda12();
                case Sequence.TEXT_BYTE_VALUE /*28*/:
                    return bilgigr.lambda13();
                case Sequence.CHAR_VALUE /*29*/:
                    return bilgigr.lambda14();
                case XDataType.DAY_TIME_DURATION_TYPE_CODE /*30*/:
                    return bilgigr.lambda15();
                case Sequence.CDATA_VALUE /*31*/:
                    return bilgigr.lambda16();
                case SetExp.SET_IF_UNBOUND /*32*/:
                    return bilgigr.lambda17();
                case Sequence.ELEMENT_VALUE /*33*/:
                    return bilgigr.lambda18();
                case Sequence.DOCUMENT_VALUE /*34*/:
                    return bilgigr.lambda19();
                case Sequence.ATTRIBUTE_VALUE /*35*/:
                    return bilgigr.lambda20();
                case Sequence.COMMENT_VALUE /*36*/:
                    return bilgigr.lambda21();
                case Sequence.PROCESSING_INSTRUCTION_VALUE /*37*/:
                    return bilgigr.lambda22();
                case XDataType.STRING_TYPE_CODE /*38*/:
                    return bilgigr.lambda23();
                case XDataType.NORMALIZED_STRING_TYPE_CODE /*39*/:
                    return bilgigr.lambda24();
                case XDataType.TOKEN_TYPE_CODE /*40*/:
                    return bilgigr.lambda25();
                case XDataType.LANGUAGE_TYPE_CODE /*41*/:
                    return bilgigr.lambda26();
                case XDataType.NMTOKEN_TYPE_CODE /*42*/:
                    return bilgigr.lambda27();
                case XDataType.NAME_TYPE_CODE /*43*/:
                    return bilgigr.lambda28();
                case XDataType.NCNAME_TYPE_CODE /*44*/:
                    return bilgigr.lambda29();
                case XDataType.ID_TYPE_CODE /*45*/:
                    return bilgigr.lambda30();
                case XDataType.IDREF_TYPE_CODE /*46*/:
                    return bilgigr.lambda31();
                case XDataType.ENTITY_TYPE_CODE /*47*/:
                    return bilgigr.lambda32();
                case XDataType.UNTYPED_TYPE_CODE /*48*/:
                    return bilgigr.lambda33();
                case 49:
                    return this.$main.OnayaBTN$Click();
                case 50:
                    return bilgigr.lambda34();
                case 51:
                    return bilgigr.lambda35();
                case 52:
                    return bilgigr.lambda36();
                case 53:
                    return bilgigr.lambda37();
                case 54:
                    return this.$main.GeriBTN$Click();
                case 55:
                    return bilgigr.lambda38();
                case 56:
                    return bilgigr.lambda39();
                case 57:
                    return bilgigr.lambda40();
                case 58:
                    return bilgigr.lambda41();
                case 59:
                    return this.$main.FOTOBUTON$Click();
                case 60:
                    return bilgigr.lambda42();
                case 61:
                    return bilgigr.lambda43();
                case 62:
                    return bilgigr.lambda44();
                case 63:
                    return bilgigr.lambda45();
                case SetExp.HAS_VALUE /*64*/:
                    return bilgigr.lambda46();
                case 65:
                    return bilgigr.lambda47();
                case 66:
                    return this.$main.FisGorBTN$Click();
                case 67:
                    return bilgigr.lambda48();
                case 68:
                    return bilgigr.lambda49();
                default:
                    return super.apply0(moduleMethod);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            switch (moduleMethod.selector) {
                case ArithOp.XOR /*15*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case SetExp.PROCEDURE /*16*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U8_VALUE /*17*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S8_VALUE /*18*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U16_VALUE /*19*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S16_VALUE /*20*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U32_VALUE /*21*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S32_VALUE /*22*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U64_VALUE /*23*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S64_VALUE /*24*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.FLOAT_VALUE /*25*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.DOUBLE_VALUE /*26*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.BOOLEAN_VALUE /*27*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.TEXT_BYTE_VALUE /*28*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.CHAR_VALUE /*29*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.DAY_TIME_DURATION_TYPE_CODE /*30*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.CDATA_VALUE /*31*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case SetExp.SET_IF_UNBOUND /*32*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.ELEMENT_VALUE /*33*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.DOCUMENT_VALUE /*34*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.ATTRIBUTE_VALUE /*35*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.COMMENT_VALUE /*36*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.PROCESSING_INSTRUCTION_VALUE /*37*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.STRING_TYPE_CODE /*38*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.NORMALIZED_STRING_TYPE_CODE /*39*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.TOKEN_TYPE_CODE /*40*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.LANGUAGE_TYPE_CODE /*41*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.NMTOKEN_TYPE_CODE /*42*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.NAME_TYPE_CODE /*43*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.NCNAME_TYPE_CODE /*44*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.ID_TYPE_CODE /*45*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.IDREF_TYPE_CODE /*46*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.ENTITY_TYPE_CODE /*47*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.UNTYPED_TYPE_CODE /*48*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 49:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 50:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 51:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 52:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 53:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 54:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 55:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 56:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 57:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 58:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 59:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 60:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 61:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 62:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 63:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case SetExp.HAS_VALUE /*64*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 65:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 66:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 67:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case 68:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod, callContext);
            }
        }
    }

    static {
        Lit174 = (SimpleSymbol) new SimpleSymbol("any").readResolve();
        Lit173 = (SimpleSymbol) new SimpleSymbol("lookup-handler").readResolve();
        Lit172 = (SimpleSymbol) new SimpleSymbol("dispatchEvent").readResolve();
        Lit171 = (SimpleSymbol) new SimpleSymbol("send-error").readResolve();
        Lit170 = (SimpleSymbol) new SimpleSymbol("add-to-form-do-after-creation").readResolve();
        Lit169 = (SimpleSymbol) new SimpleSymbol("add-to-global-vars").readResolve();
        Lit168 = (SimpleSymbol) new SimpleSymbol("add-to-components").readResolve();
        Lit167 = (SimpleSymbol) new SimpleSymbol("add-to-events").readResolve();
        Lit166 = (SimpleSymbol) new SimpleSymbol("add-to-global-var-environment").readResolve();
        Lit165 = (SimpleSymbol) new SimpleSymbol("is-bound-in-form-environment").readResolve();
        Lit164 = (SimpleSymbol) new SimpleSymbol("lookup-in-form-environment").readResolve();
        Lit163 = (SimpleSymbol) new SimpleSymbol("add-to-form-environment").readResolve();
        Lit162 = (SimpleSymbol) new SimpleSymbol("android-log-form").readResolve();
        Lit161 = (SimpleSymbol) new SimpleSymbol("AfterPicture").readResolve();
        Lit160 = (SimpleSymbol) new SimpleSymbol("Camera1$AfterPicture").readResolve();
        SimpleSymbol simpleSymbol = (SimpleSymbol) new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT).readResolve();
        Lit4 = simpleSymbol;
        Lit159 = PairWithPosition.make(simpleSymbol, PairWithPosition.make(Lit174, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 1396957), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 1396951);
        Lit158 = (SimpleSymbol) new SimpleSymbol("$image").readResolve();
        Lit157 = new FString("com.google.appinventor.components.runtime.Camera");
        Lit156 = new FString("com.google.appinventor.components.runtime.Camera");
        Lit155 = new FString("com.google.appinventor.components.runtime.TinyDB");
        Lit154 = new FString("com.google.appinventor.components.runtime.TinyDB");
        Lit153 = new FString("com.google.appinventor.components.runtime.Canvas");
        Lit152 = (SimpleSymbol) new SimpleSymbol("TextAlignment").readResolve();
        Lit151 = IntNum.make(220);
        Lit150 = IntNum.make((int) FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK);
        Lit149 = new FString("com.google.appinventor.components.runtime.Canvas");
        Lit148 = (SimpleSymbol) new SimpleSymbol("FisGorBTN$Click").readResolve();
        Lit147 = PairWithPosition.make(Lit4, PairWithPosition.make(Lit174, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 1302678), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 1302672);
        Lit146 = (SimpleSymbol) new SimpleSymbol("BackgroundImage").readResolve();
        Lit145 = (SimpleSymbol) new SimpleSymbol("FisCanvas").readResolve();
        Lit144 = new FString("com.google.appinventor.components.runtime.Button");
        Lit143 = IntNum.make(50);
        Lit142 = (SimpleSymbol) new SimpleSymbol("FisGorBTN").readResolve();
        Lit141 = new FString("com.google.appinventor.components.runtime.Button");
        Lit140 = new FString("com.google.appinventor.components.runtime.Label");
        int[] iArr = new int[2];
        iArr[0] = -1;
        Lit139 = IntNum.make(iArr);
        Lit138 = DFloNum.make((double) 17);
        iArr = new int[2];
        iArr[0] = Component.COLOR_RED;
        Lit137 = IntNum.make(iArr);
        Lit136 = (SimpleSymbol) new SimpleSymbol("FisGorLB").readResolve();
        Lit135 = new FString("com.google.appinventor.components.runtime.Label");
        Lit134 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit133 = (SimpleSymbol) new SimpleSymbol("VerticalArrangement2").readResolve();
        Lit132 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit131 = new FString("com.google.appinventor.components.runtime.Label");
        Lit130 = IntNum.make(5);
        Lit129 = (SimpleSymbol) new SimpleSymbol("Label2").readResolve();
        Lit128 = new FString("com.google.appinventor.components.runtime.Label");
        Lit127 = (SimpleSymbol) new SimpleSymbol("FOTOBUTON$Click").readResolve();
        Lit126 = (SimpleSymbol) new SimpleSymbol("TakePicture").readResolve();
        Lit125 = (SimpleSymbol) new SimpleSymbol("Camera1").readResolve();
        Lit124 = new FString("com.google.appinventor.components.runtime.Button");
        Lit123 = (SimpleSymbol) new SimpleSymbol("Shape").readResolve();
        Lit122 = (SimpleSymbol) new SimpleSymbol("FOTOBUTON").readResolve();
        Lit121 = new FString("com.google.appinventor.components.runtime.Button");
        Lit120 = new FString("com.google.appinventor.components.runtime.Label");
        iArr = new int[2];
        iArr[0] = -1;
        Lit119 = IntNum.make(iArr);
        Lit118 = (SimpleSymbol) new SimpleSymbol("TextColor").readResolve();
        Lit117 = DFloNum.make((double) 17);
        Lit116 = (SimpleSymbol) new SimpleSymbol("FontSize").readResolve();
        iArr = new int[2];
        iArr[0] = Component.COLOR_RED;
        Lit115 = IntNum.make(iArr);
        Lit114 = (SimpleSymbol) new SimpleSymbol("BackgroundColor").readResolve();
        Lit113 = (SimpleSymbol) new SimpleSymbol("FisLB").readResolve();
        Lit112 = new FString("com.google.appinventor.components.runtime.Label");
        Lit111 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit110 = (SimpleSymbol) new SimpleSymbol("VerticalArrangement1").readResolve();
        Lit109 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit108 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit107 = (SimpleSymbol) new SimpleSymbol("HorizontalArrangement2").readResolve();
        Lit106 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit105 = (SimpleSymbol) new SimpleSymbol("GeriBTN$Click").readResolve();
        Lit104 = new FString("com.google.appinventor.components.runtime.Button");
        Lit103 = (SimpleSymbol) new SimpleSymbol("GeriBTN").readResolve();
        Lit102 = new FString("com.google.appinventor.components.runtime.Button");
        Lit101 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit100 = (SimpleSymbol) new SimpleSymbol("HorizontalArrangement5").readResolve();
        Lit99 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit98 = new FString("com.google.appinventor.components.runtime.Label");
        Lit97 = IntNum.make(10);
        Lit96 = (SimpleSymbol) new SimpleSymbol("Label1").readResolve();
        Lit95 = new FString("com.google.appinventor.components.runtime.Label");
        Lit94 = (SimpleSymbol) new SimpleSymbol("Click").readResolve();
        Lit93 = (SimpleSymbol) new SimpleSymbol("OnayaBTN$Click").readResolve();
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("number").readResolve();
        Lit21 = simpleSymbol;
        Lit92 = PairWithPosition.make(simpleSymbol, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824551), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824543);
        Lit91 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824527), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824519);
        Lit90 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824502), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824494);
        Lit89 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824477), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 824469);
        Lit88 = PairWithPosition.make(Lit4, PairWithPosition.make(Lit174, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823885), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823879);
        Lit87 = (SimpleSymbol) new SimpleSymbol("StoreValue").readResolve();
        Lit86 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823754), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823746);
        Lit85 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823730), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823722);
        Lit84 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823705), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823697);
        Lit83 = PairWithPosition.make(Lit21, PairWithPosition.make(Lit21, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823680), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 823672);
        Lit82 = new FString("com.google.appinventor.components.runtime.Button");
        Lit81 = (SimpleSymbol) new SimpleSymbol("Image").readResolve();
        Lit80 = IntNum.make(60);
        Lit79 = (SimpleSymbol) new SimpleSymbol("OnayaBTN").readResolve();
        Lit78 = new FString("com.google.appinventor.components.runtime.Button");
        Lit77 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit76 = IntNum.make(150);
        Lit75 = (SimpleSymbol) new SimpleSymbol("ResultTX").readResolve();
        Lit74 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit73 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit72 = (SimpleSymbol) new SimpleSymbol("HorizontalArrangement3").readResolve();
        Lit71 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit70 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit69 = (SimpleSymbol) new SimpleSymbol("DigerTX").readResolve();
        Lit68 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit67 = new FString("com.google.appinventor.components.runtime.Label");
        Lit66 = (SimpleSymbol) new SimpleSymbol("DigerLB").readResolve();
        Lit65 = new FString("com.google.appinventor.components.runtime.Label");
        Lit64 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit63 = (SimpleSymbol) new SimpleSymbol("HorizontalArrangement1").readResolve();
        Lit62 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit61 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit60 = (SimpleSymbol) new SimpleSymbol("FaturalarTX").readResolve();
        Lit59 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit58 = new FString("com.google.appinventor.components.runtime.Label");
        Lit57 = (SimpleSymbol) new SimpleSymbol("FaturalarLB").readResolve();
        Lit56 = new FString("com.google.appinventor.components.runtime.Label");
        Lit55 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit54 = (SimpleSymbol) new SimpleSymbol("TaksitTX").readResolve();
        Lit53 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit52 = new FString("com.google.appinventor.components.runtime.Label");
        Lit51 = (SimpleSymbol) new SimpleSymbol("TaksitLB").readResolve();
        Lit50 = new FString("com.google.appinventor.components.runtime.Label");
        Lit49 = new FString("com.google.appinventor.components.runtime.TableArrangement");
        Lit48 = (SimpleSymbol) new SimpleSymbol("TableArrangement2").readResolve();
        Lit47 = new FString("com.google.appinventor.components.runtime.TableArrangement");
        Lit46 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit45 = (SimpleSymbol) new SimpleSymbol("KiraTX").readResolve();
        Lit44 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit43 = new FString("com.google.appinventor.components.runtime.Label");
        Lit42 = (SimpleSymbol) new SimpleSymbol("KiraLB").readResolve();
        Lit41 = new FString("com.google.appinventor.components.runtime.Label");
        Lit40 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit39 = (SimpleSymbol) new SimpleSymbol("HorizontalArrangement4").readResolve();
        Lit38 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit37 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit36 = (SimpleSymbol) new SimpleSymbol("NumbersOnly").readResolve();
        Lit35 = (SimpleSymbol) new SimpleSymbol("Hint").readResolve();
        Lit34 = (SimpleSymbol) new SimpleSymbol("FontBold").readResolve();
        Lit33 = IntNum.make(1);
        Lit32 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit31 = new FString("com.google.appinventor.components.runtime.Label");
        Lit30 = (SimpleSymbol) new SimpleSymbol("Row").readResolve();
        Lit29 = (SimpleSymbol) new SimpleSymbol("HasMargins").readResolve();
        Lit28 = IntNum.make(0);
        Lit27 = (SimpleSymbol) new SimpleSymbol("Column").readResolve();
        Lit26 = (SimpleSymbol) new SimpleSymbol("AylikLB").readResolve();
        Lit25 = new FString("com.google.appinventor.components.runtime.Label");
        Lit24 = new FString("com.google.appinventor.components.runtime.TableArrangement");
        Lit23 = IntNum.make(-2);
        Lit22 = (SimpleSymbol) new SimpleSymbol("Width").readResolve();
        Lit20 = IntNum.make(40);
        Lit19 = (SimpleSymbol) new SimpleSymbol("Height").readResolve();
        Lit18 = (SimpleSymbol) new SimpleSymbol("TableArrangement1").readResolve();
        Lit17 = new FString("com.google.appinventor.components.runtime.TableArrangement");
        Lit16 = (SimpleSymbol) new SimpleSymbol("Initialize").readResolve();
        Lit15 = (SimpleSymbol) new SimpleSymbol("bilgigr$Initialize").readResolve();
        Lit14 = PairWithPosition.make(Lit4, PairWithPosition.make(Lit174, LList.Empty, "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 73856), "/tmp/1494085374821_0.2445770148345492-0/youngandroidproject/../src/appinventor/ai_burakdemirci25/CUZDANIM/bilgigr.yail", 73850);
        Lit13 = (SimpleSymbol) new SimpleSymbol("GetValue").readResolve();
        Lit12 = (SimpleSymbol) new SimpleSymbol("TinyDB1").readResolve();
        Lit11 = (SimpleSymbol) new SimpleSymbol("Text").readResolve();
        Lit10 = (SimpleSymbol) new SimpleSymbol("AYLIKTX").readResolve();
        Lit9 = (SimpleSymbol) new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN).readResolve();
        Lit8 = (SimpleSymbol) new SimpleSymbol("Scrollable").readResolve();
        Lit7 = (SimpleSymbol) new SimpleSymbol("ScreenOrientation").readResolve();
        Lit6 = (SimpleSymbol) new SimpleSymbol("OpenScreenAnimation").readResolve();
        Lit5 = (SimpleSymbol) new SimpleSymbol("CloseScreenAnimation").readResolve();
        Lit3 = (SimpleSymbol) new SimpleSymbol("AppName").readResolve();
        Lit2 = (SimpleSymbol) new SimpleSymbol("*the-null-value*").readResolve();
        Lit1 = (SimpleSymbol) new SimpleSymbol("getMessage").readResolve();
        Lit0 = (SimpleSymbol) new SimpleSymbol("bilgigr").readResolve();
    }

    public bilgigr() {
        ModuleInfo.register(this);
        ModuleBody appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame = new frame();
        appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame.$main = this;
        this.android$Mnlog$Mnform = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 1, Lit162, 4097);
        this.add$Mnto$Mnform$Mnenvironment = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 2, Lit163, 8194);
        this.lookup$Mnin$Mnform$Mnenvironment = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 3, Lit164, 8193);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 5, Lit165, 4097);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 6, Lit166, 8194);
        this.add$Mnto$Mnevents = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 7, Lit167, 8194);
        this.add$Mnto$Mncomponents = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 8, Lit168, 16388);
        this.add$Mnto$Mnglobal$Mnvars = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 9, Lit169, 8194);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 10, Lit170, 4097);
        this.send$Mnerror = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 11, Lit171, 4097);
        this.process$Mnexception = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 12, "process-exception", 4097);
        this.dispatchEvent = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 13, Lit172, 16388);
        this.lookup$Mnhandler = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 14, Lit173, 8194);
        PropertySet moduleMethod = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 15, null, 0);
        moduleMethod.setProperty("source-location", "/tmp/runtime8953333599456942930.scm:552");
        lambda$Fn1 = moduleMethod;
        this.$define = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 16, "$define", 0);
        lambda$Fn2 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 17, null, 0);
        this.bilgigr$Initialize = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 18, Lit15, 0);
        lambda$Fn3 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 19, null, 0);
        lambda$Fn4 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 20, null, 0);
        lambda$Fn5 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 21, null, 0);
        lambda$Fn6 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 22, null, 0);
        lambda$Fn7 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 23, null, 0);
        lambda$Fn8 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 24, null, 0);
        lambda$Fn9 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 25, null, 0);
        lambda$Fn10 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 26, null, 0);
        lambda$Fn11 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 27, null, 0);
        lambda$Fn12 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 28, null, 0);
        lambda$Fn13 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 29, null, 0);
        lambda$Fn14 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 30, null, 0);
        lambda$Fn15 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 31, null, 0);
        lambda$Fn16 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 32, null, 0);
        lambda$Fn17 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 33, null, 0);
        lambda$Fn18 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 34, null, 0);
        lambda$Fn19 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 35, null, 0);
        lambda$Fn20 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 36, null, 0);
        lambda$Fn21 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 37, null, 0);
        lambda$Fn22 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 38, null, 0);
        lambda$Fn23 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 39, null, 0);
        lambda$Fn24 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 40, null, 0);
        lambda$Fn25 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 41, null, 0);
        lambda$Fn26 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 42, null, 0);
        lambda$Fn27 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 43, null, 0);
        lambda$Fn28 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 44, null, 0);
        lambda$Fn29 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 45, null, 0);
        lambda$Fn30 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 46, null, 0);
        lambda$Fn31 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 47, null, 0);
        lambda$Fn32 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 48, null, 0);
        this.OnayaBTN$Click = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 49, Lit93, 0);
        lambda$Fn33 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 50, null, 0);
        lambda$Fn34 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 51, null, 0);
        lambda$Fn35 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 52, null, 0);
        lambda$Fn36 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 53, null, 0);
        this.GeriBTN$Click = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 54, Lit105, 0);
        lambda$Fn37 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 55, null, 0);
        lambda$Fn38 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 56, null, 0);
        lambda$Fn39 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 57, null, 0);
        lambda$Fn40 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 58, null, 0);
        this.FOTOBUTON$Click = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 59, Lit127, 0);
        lambda$Fn41 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 60, null, 0);
        lambda$Fn42 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 61, null, 0);
        lambda$Fn43 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 62, null, 0);
        lambda$Fn44 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 63, null, 0);
        lambda$Fn45 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 64, null, 0);
        lambda$Fn46 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 65, null, 0);
        this.FisGorBTN$Click = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 66, Lit148, 0);
        lambda$Fn47 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 67, null, 0);
        lambda$Fn48 = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 68, null, 0);
        this.Camera1$AfterPicture = new ModuleMethod(appinventor_ai_burakdemirci25_CUZDANIM_bilgigr_frame, 69, Lit160, 4097);
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        Consumer $result = $ctx.consumer;
        Object find = require.find("com.google.youngandroid.runtime");
        try {
            String str;
            ((Runnable) find).run();
            this.$Stdebug$Mnform$St = Boolean.FALSE;
            this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
            FString stringAppend = strings.stringAppend(misc.symbol$To$String(Lit0), "-global-vars");
            if (stringAppend == null) {
                str = null;
            } else {
                str = stringAppend.toString();
            }
            this.global$Mnvar$Mnenvironment = Environment.make(str);
            bilgigr = null;
            this.form$Mnname$Mnsymbol = Lit0;
            this.events$Mnto$Mnregister = LList.Empty;
            this.components$Mnto$Mncreate = LList.Empty;
            this.global$Mnvars$Mnto$Mncreate = LList.Empty;
            this.form$Mndo$Mnafter$Mncreation = LList.Empty;
            find = require.find("com.google.youngandroid.runtime");
            try {
                ((Runnable) find).run();
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit3, "CUZDANIM", Lit4);
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit5, "slidehorizontal", Lit4);
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit6, "slidehorizontal", Lit4);
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit7, "user", Lit4);
                    Values.writeValues(runtime.setAndCoerceProperty$Ex(Lit0, Lit8, Boolean.TRUE, Lit9), $result);
                } else {
                    addToFormDoAfterCreation(new Promise(lambda$Fn2));
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit15, this.bilgigr$Initialize);
                } else {
                    addToFormEnvironment(Lit15, this.bilgigr$Initialize);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "bilgigr", "Initialize");
                } else {
                    addToEvents(Lit0, Lit16);
                }
                this.TableArrangement1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit17, Lit18, lambda$Fn3), $result);
                } else {
                    addToComponents(Lit0, Lit24, Lit18, lambda$Fn4);
                }
                this.AylikLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit25, Lit26, lambda$Fn5), $result);
                } else {
                    addToComponents(Lit18, Lit31, Lit26, lambda$Fn6);
                }
                this.AYLIKTX = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit32, Lit10, lambda$Fn7), $result);
                } else {
                    addToComponents(Lit18, Lit37, Lit10, lambda$Fn8);
                }
                this.HorizontalArrangement4 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit38, Lit39, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit40, Lit39, Boolean.FALSE);
                }
                this.KiraLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit39, Lit41, Lit42, lambda$Fn9), $result);
                } else {
                    addToComponents(Lit39, Lit43, Lit42, lambda$Fn10);
                }
                this.KiraTX = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit39, Lit44, Lit45, lambda$Fn11), $result);
                } else {
                    addToComponents(Lit39, Lit46, Lit45, lambda$Fn12);
                }
                this.TableArrangement2 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit47, Lit48, lambda$Fn13), $result);
                } else {
                    addToComponents(Lit0, Lit49, Lit48, lambda$Fn14);
                }
                this.TaksitLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit48, Lit50, Lit51, lambda$Fn15), $result);
                } else {
                    addToComponents(Lit48, Lit52, Lit51, lambda$Fn16);
                }
                this.TaksitTX = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit48, Lit53, Lit54, lambda$Fn17), $result);
                } else {
                    addToComponents(Lit48, Lit55, Lit54, lambda$Fn18);
                }
                this.FaturalarLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit48, Lit56, Lit57, lambda$Fn19), $result);
                } else {
                    addToComponents(Lit48, Lit58, Lit57, lambda$Fn20);
                }
                this.FaturalarTX = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit48, Lit59, Lit60, lambda$Fn21), $result);
                } else {
                    addToComponents(Lit48, Lit61, Lit60, lambda$Fn22);
                }
                this.HorizontalArrangement1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit62, Lit63, lambda$Fn23), $result);
                } else {
                    addToComponents(Lit0, Lit64, Lit63, lambda$Fn24);
                }
                this.DigerLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit63, Lit65, Lit66, lambda$Fn25), $result);
                } else {
                    addToComponents(Lit63, Lit67, Lit66, lambda$Fn26);
                }
                this.DigerTX = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit63, Lit68, Lit69, lambda$Fn27), $result);
                } else {
                    addToComponents(Lit63, Lit70, Lit69, lambda$Fn28);
                }
                this.HorizontalArrangement3 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit71, Lit72, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit73, Lit72, Boolean.FALSE);
                }
                this.ResultTX = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit72, Lit74, Lit75, lambda$Fn29), $result);
                } else {
                    addToComponents(Lit72, Lit77, Lit75, lambda$Fn30);
                }
                this.OnayaBTN = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit72, Lit78, Lit79, lambda$Fn31), $result);
                } else {
                    addToComponents(Lit72, Lit82, Lit79, lambda$Fn32);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit93, this.OnayaBTN$Click);
                } else {
                    addToFormEnvironment(Lit93, this.OnayaBTN$Click);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "OnayaBTN", "Click");
                } else {
                    addToEvents(Lit79, Lit94);
                }
                this.Label1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit72, Lit95, Lit96, lambda$Fn33), $result);
                } else {
                    addToComponents(Lit72, Lit98, Lit96, lambda$Fn34);
                }
                this.HorizontalArrangement5 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit72, Lit99, Lit100, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit72, Lit101, Lit100, Boolean.FALSE);
                }
                this.GeriBTN = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit100, Lit102, Lit103, lambda$Fn35), $result);
                } else {
                    addToComponents(Lit100, Lit104, Lit103, lambda$Fn36);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit105, this.GeriBTN$Click);
                } else {
                    addToFormEnvironment(Lit105, this.GeriBTN$Click);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "GeriBTN", "Click");
                } else {
                    addToEvents(Lit103, Lit94);
                }
                this.HorizontalArrangement2 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit106, Lit107, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit108, Lit107, Boolean.FALSE);
                }
                this.VerticalArrangement1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit109, Lit110, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit107, Lit111, Lit110, Boolean.FALSE);
                }
                this.FisLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit110, Lit112, Lit113, lambda$Fn37), $result);
                } else {
                    addToComponents(Lit110, Lit120, Lit113, lambda$Fn38);
                }
                this.FOTOBUTON = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit110, Lit121, Lit122, lambda$Fn39), $result);
                } else {
                    addToComponents(Lit110, Lit124, Lit122, lambda$Fn40);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit127, this.FOTOBUTON$Click);
                } else {
                    addToFormEnvironment(Lit127, this.FOTOBUTON$Click);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "FOTOBUTON", "Click");
                } else {
                    addToEvents(Lit122, Lit94);
                }
                this.Label2 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit110, Lit128, Lit129, lambda$Fn41), $result);
                } else {
                    addToComponents(Lit110, Lit131, Lit129, lambda$Fn42);
                }
                this.VerticalArrangement2 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit110, Lit132, Lit133, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit110, Lit134, Lit133, Boolean.FALSE);
                }
                this.FisGorLB = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit133, Lit135, Lit136, lambda$Fn43), $result);
                } else {
                    addToComponents(Lit133, Lit140, Lit136, lambda$Fn44);
                }
                this.FisGorBTN = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit110, Lit141, Lit142, lambda$Fn45), $result);
                } else {
                    addToComponents(Lit110, Lit144, Lit142, lambda$Fn46);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit148, this.FisGorBTN$Click);
                } else {
                    addToFormEnvironment(Lit148, this.FisGorBTN$Click);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "FisGorBTN", "Click");
                } else {
                    addToEvents(Lit142, Lit94);
                }
                this.FisCanvas = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit149, Lit145, lambda$Fn47), $result);
                } else {
                    addToComponents(Lit107, Lit153, Lit145, lambda$Fn48);
                }
                this.TinyDB1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit154, Lit12, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit155, Lit12, Boolean.FALSE);
                }
                this.Camera1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit156, Lit125, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit157, Lit125, Boolean.FALSE);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit160, this.Camera1$AfterPicture);
                } else {
                    addToFormEnvironment(Lit160, this.Camera1$AfterPicture);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "Camera1", "AfterPicture");
                } else {
                    addToEvents(Lit125, Lit161);
                }
                runtime.initRuntime();
            } catch (ClassCastException e) {
                throw new WrongType(e, "java.lang.Runnable.run()", 1, find);
            }
        } catch (ClassCastException e2) {
            throw new WrongType(e2, "java.lang.Runnable.run()", 1, find);
        }
    }

    static Object lambda3() {
        runtime.setAndCoerceProperty$Ex(Lit0, Lit3, "CUZDANIM", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit0, Lit5, "slidehorizontal", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit0, Lit6, "slidehorizontal", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit0, Lit7, "user", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit0, Lit8, Boolean.TRUE, Lit9);
    }

    public Object bilgigr$Initialize() {
        runtime.setThisForm();
        return runtime.setAndCoerceProperty$Ex(Lit10, Lit11, runtime.callComponentMethod(Lit12, Lit13, LList.list2("kalan", ElementType.MATCH_ANY_LOCALNAME), Lit14), Lit4);
    }

    static Object lambda4() {
        runtime.setAndCoerceProperty$Ex(Lit18, Lit19, Lit20, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit18, Lit22, Lit23, Lit21);
    }

    static Object lambda5() {
        runtime.setAndCoerceProperty$Ex(Lit18, Lit19, Lit20, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit18, Lit22, Lit23, Lit21);
    }

    static Object lambda6() {
        runtime.setAndCoerceProperty$Ex(Lit26, Lit27, Lit28, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit26, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit26, Lit30, Lit28, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit26, Lit11, "AYLIK", Lit4);
    }

    static Object lambda7() {
        runtime.setAndCoerceProperty$Ex(Lit26, Lit27, Lit28, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit26, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit26, Lit30, Lit28, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit26, Lit11, "AYLIK", Lit4);
    }

    static Object lambda8() {
        runtime.setAndCoerceProperty$Ex(Lit10, Lit27, Lit33, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit10, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit10, Lit35, "AYLIK", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit10, Lit36, Boolean.TRUE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit10, Lit30, Lit28, Lit21);
    }

    static Object lambda9() {
        runtime.setAndCoerceProperty$Ex(Lit10, Lit27, Lit33, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit10, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit10, Lit35, "AYLIK", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit10, Lit36, Boolean.TRUE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit10, Lit30, Lit28, Lit21);
    }

    static Object lambda10() {
        runtime.setAndCoerceProperty$Ex(Lit42, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit42, Lit11, "K\u0130RA", Lit4);
    }

    static Object lambda11() {
        runtime.setAndCoerceProperty$Ex(Lit42, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit42, Lit11, "K\u0130RA", Lit4);
    }

    static Object lambda12() {
        runtime.setAndCoerceProperty$Ex(Lit45, Lit35, "Hint for TextBox1", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit45, Lit36, Boolean.TRUE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit45, Lit11, "0", Lit4);
    }

    static Object lambda13() {
        runtime.setAndCoerceProperty$Ex(Lit45, Lit35, "Hint for TextBox1", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit45, Lit36, Boolean.TRUE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit45, Lit11, "0", Lit4);
    }

    static Object lambda14() {
        return runtime.setAndCoerceProperty$Ex(Lit48, Lit22, Lit23, Lit21);
    }

    static Object lambda15() {
        return runtime.setAndCoerceProperty$Ex(Lit48, Lit22, Lit23, Lit21);
    }

    static Object lambda16() {
        runtime.setAndCoerceProperty$Ex(Lit51, Lit27, Lit28, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit51, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit51, Lit30, Lit28, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit51, Lit11, "TAKS\u0130T", Lit4);
    }

    static Object lambda17() {
        runtime.setAndCoerceProperty$Ex(Lit51, Lit27, Lit28, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit51, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit51, Lit30, Lit28, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit51, Lit11, "TAKS\u0130T", Lit4);
    }

    static Object lambda18() {
        runtime.setAndCoerceProperty$Ex(Lit54, Lit27, Lit33, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit35, "Hint for TextBox1", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit36, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit30, Lit28, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit54, Lit11, "0", Lit4);
    }

    static Object lambda19() {
        runtime.setAndCoerceProperty$Ex(Lit54, Lit27, Lit33, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit35, "Hint for TextBox1", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit36, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit30, Lit28, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit54, Lit11, "0", Lit4);
    }

    static Object lambda20() {
        runtime.setAndCoerceProperty$Ex(Lit57, Lit27, Lit28, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit57, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit57, Lit30, Lit33, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit57, Lit11, "FATURA", Lit4);
    }

    static Object lambda21() {
        runtime.setAndCoerceProperty$Ex(Lit57, Lit27, Lit28, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit57, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit57, Lit30, Lit33, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit57, Lit11, "FATURA", Lit4);
    }

    static Object lambda22() {
        runtime.setAndCoerceProperty$Ex(Lit60, Lit27, Lit33, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit35, "Hint for TextBox2", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit36, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit30, Lit33, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit60, Lit11, "0", Lit4);
    }

    static Object lambda23() {
        runtime.setAndCoerceProperty$Ex(Lit60, Lit27, Lit33, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit35, "Hint for TextBox2", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit36, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit30, Lit33, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit60, Lit11, "0", Lit4);
    }

    static Object lambda24() {
        return runtime.setAndCoerceProperty$Ex(Lit63, Lit22, Lit23, Lit21);
    }

    static Object lambda25() {
        return runtime.setAndCoerceProperty$Ex(Lit63, Lit22, Lit23, Lit21);
    }

    static Object lambda26() {
        runtime.setAndCoerceProperty$Ex(Lit66, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit66, Lit11, "D\u0130\u011eER", Lit4);
    }

    static Object lambda27() {
        runtime.setAndCoerceProperty$Ex(Lit66, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit66, Lit11, "D\u0130\u011eER", Lit4);
    }

    static Object lambda28() {
        runtime.setAndCoerceProperty$Ex(Lit69, Lit35, "Hint for TextBox3", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit69, Lit36, Boolean.TRUE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit69, Lit11, "0", Lit4);
    }

    static Object lambda29() {
        runtime.setAndCoerceProperty$Ex(Lit69, Lit35, "Hint for TextBox3", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit69, Lit36, Boolean.TRUE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit69, Lit11, "0", Lit4);
    }

    static Object lambda30() {
        runtime.setAndCoerceProperty$Ex(Lit75, Lit22, Lit76, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit75, Lit36, Boolean.TRUE, Lit9);
    }

    static Object lambda31() {
        runtime.setAndCoerceProperty$Ex(Lit75, Lit22, Lit76, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit75, Lit36, Boolean.TRUE, Lit9);
    }

    static Object lambda32() {
        runtime.setAndCoerceProperty$Ex(Lit79, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit79, Lit19, Lit20, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit79, Lit22, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit79, Lit81, "Tik.jpg", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit79, Lit11, "ONAYLA", Lit4);
    }

    static Object lambda33() {
        runtime.setAndCoerceProperty$Ex(Lit79, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit79, Lit19, Lit20, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit79, Lit22, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit79, Lit81, "Tik.jpg", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit79, Lit11, "ONAYLA", Lit4);
    }

    public Object OnayaBTN$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit75, Lit11, runtime.callYailPrimitive(AddOp.$Mn, LList.list2(runtime.getProperty$1(Lit10, Lit11), runtime.callYailPrimitive(AddOp.$Pl, LList.list2(runtime.getProperty$1(Lit45, Lit11), runtime.callYailPrimitive(AddOp.$Pl, LList.list2(runtime.getProperty$1(Lit54, Lit11), runtime.callYailPrimitive(AddOp.$Pl, LList.list2(runtime.getProperty$1(Lit69, Lit11), runtime.getProperty$1(Lit60, Lit11)), Lit83, "+")), Lit84, "+")), Lit85, "+")), Lit86, "-"), Lit4);
        runtime.callComponentMethod(Lit12, Lit87, LList.list2("kalan", runtime.getProperty$1(Lit75, Lit11)), Lit88);
        runtime.setAndCoerceProperty$Ex(Lit54, Lit11, "0", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit45, Lit11, "0", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit60, Lit11, "0", Lit4);
        runtime.setAndCoerceProperty$Ex(Lit69, Lit11, "0", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit10, Lit11, runtime.callYailPrimitive(AddOp.$Mn, LList.list2(runtime.getProperty$1(Lit75, Lit11), runtime.callYailPrimitive(AddOp.$Pl, LList.list2(runtime.getProperty$1(Lit45, Lit11), runtime.callYailPrimitive(AddOp.$Pl, LList.list2(runtime.getProperty$1(Lit54, Lit11), runtime.callYailPrimitive(AddOp.$Pl, LList.list2(runtime.getProperty$1(Lit69, Lit11), runtime.getProperty$1(Lit60, Lit11)), Lit89, "+")), Lit90, "+")), Lit91, "+")), Lit92, "-"), Lit4);
    }

    static Object lambda34() {
        runtime.setAndCoerceProperty$Ex(Lit96, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit96, Lit22, Lit97, Lit21);
    }

    static Object lambda35() {
        runtime.setAndCoerceProperty$Ex(Lit96, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit96, Lit22, Lit97, Lit21);
    }

    static Object lambda36() {
        runtime.setAndCoerceProperty$Ex(Lit103, Lit19, Lit20, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit103, Lit22, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit103, Lit81, "back.png", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit103, Lit11, "GER\u0130", Lit4);
    }

    static Object lambda37() {
        runtime.setAndCoerceProperty$Ex(Lit103, Lit19, Lit20, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit103, Lit22, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit103, Lit81, "back.png", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit103, Lit11, "GER\u0130", Lit4);
    }

    public Object GeriBTN$Click() {
        runtime.setThisForm();
        return runtime.callYailPrimitive(runtime.close$Mnscreen, LList.Empty, LList.Empty, "close screen");
    }

    static Object lambda38() {
        runtime.setAndCoerceProperty$Ex(Lit113, Lit114, Lit115, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit116, Lit117, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit11, "F\u0130\u015e \u00c7EK ", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit113, Lit118, Lit119, Lit21);
    }

    static Object lambda39() {
        runtime.setAndCoerceProperty$Ex(Lit113, Lit114, Lit115, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit116, Lit117, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit113, Lit11, "F\u0130\u015e \u00c7EK ", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit113, Lit118, Lit119, Lit21);
    }

    static Object lambda40() {
        runtime.setAndCoerceProperty$Ex(Lit122, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit122, Lit19, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit122, Lit22, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit122, Lit81, "cameraicon.png", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit122, Lit123, Lit33, Lit21);
    }

    static Object lambda41() {
        runtime.setAndCoerceProperty$Ex(Lit122, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit122, Lit19, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit122, Lit22, Lit80, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit122, Lit81, "cameraicon.png", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit122, Lit123, Lit33, Lit21);
    }

    public Object FOTOBUTON$Click() {
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit125, Lit126, LList.Empty, LList.Empty);
    }

    static Object lambda42() {
        runtime.setAndCoerceProperty$Ex(Lit129, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit129, Lit19, Lit130, Lit21);
    }

    static Object lambda43() {
        runtime.setAndCoerceProperty$Ex(Lit129, Lit29, Boolean.FALSE, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit129, Lit19, Lit130, Lit21);
    }

    static Object lambda44() {
        runtime.setAndCoerceProperty$Ex(Lit136, Lit114, Lit137, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit116, Lit138, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit11, "F\u0130\u015e G\u00d6R", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit136, Lit118, Lit139, Lit21);
    }

    static Object lambda45() {
        runtime.setAndCoerceProperty$Ex(Lit136, Lit114, Lit137, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit34, Boolean.TRUE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit116, Lit138, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit29, Boolean.FALSE, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit136, Lit11, "F\u0130\u015e G\u00d6R", Lit4);
        return runtime.setAndCoerceProperty$Ex(Lit136, Lit118, Lit139, Lit21);
    }

    static Object lambda46() {
        runtime.setAndCoerceProperty$Ex(Lit142, Lit19, Lit143, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit142, Lit22, Lit80, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit142, Lit81, "fis.jpg", Lit4);
    }

    static Object lambda47() {
        runtime.setAndCoerceProperty$Ex(Lit142, Lit19, Lit143, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit142, Lit22, Lit80, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit142, Lit81, "fis.jpg", Lit4);
    }

    public Object FisGorBTN$Click() {
        runtime.setThisForm();
        return runtime.setAndCoerceProperty$Ex(Lit145, Lit146, runtime.callComponentMethod(Lit12, Lit13, LList.list2("fi\u015f resim", ElementType.MATCH_ANY_LOCALNAME), Lit147), Lit4);
    }

    static Object lambda48() {
        runtime.setAndCoerceProperty$Ex(Lit145, Lit19, Lit150, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit145, Lit22, Lit151, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit145, Lit152, Lit28, Lit21);
    }

    static Object lambda49() {
        runtime.setAndCoerceProperty$Ex(Lit145, Lit19, Lit150, Lit21);
        runtime.setAndCoerceProperty$Ex(Lit145, Lit22, Lit151, Lit21);
        return runtime.setAndCoerceProperty$Ex(Lit145, Lit152, Lit28, Lit21);
    }

    public Object Camera1$AfterPicture(Object $image) {
        $image = runtime.sanitizeComponentData($image);
        runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit145;
        SimpleSymbol simpleSymbol2 = Lit146;
        if ($image instanceof Package) {
            $image = runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit158), " is not bound in the current context"), "Unbound Variable");
        }
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, $image, Lit4);
        return runtime.callComponentMethod(Lit12, Lit87, LList.list2("fi\u015f resim", runtime.getProperty$1(Lit145, Lit146)), Lit159);
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol name, Object object) {
        androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", name, this.form$Mnenvironment, object));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol name, Object default$Mnvalue) {
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & 1;
        if (x) {
            if (!this.form$Mnenvironment.isBound(name)) {
                return default$Mnvalue;
            }
        } else if (!x) {
            return default$Mnvalue;
        }
        return this.form$Mnenvironment.get(name);
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol name, Object object) {
        androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", name, this.global$Mnvar$Mnenvironment, object));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = lists.cons(lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        RetValManager.sendError(error == null ? null : error.toString());
    }

    public void processException(Object ex) {
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component componentObject, String registeredComponentName, String eventName, Object[] args) {
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            return false;
        } else if (lookupInFormEnvironment(registeredObject) != componentObject) {
            return false;
        } else {
            try {
                Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                return true;
            } catch (Throwable exception) {
                androidLogForm(exception.getMessage());
                exception.printStackTrace();
                processException(exception);
                return false;
            }
        }
    }

    public Object lookupHandler(Object componentName, Object eventName) {
        String str = null;
        String obj = componentName == null ? null : componentName.toString();
        if (eventName != null) {
            str = eventName.toString();
        }
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj, str)));
    }

    public void $define() {
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception exception) {
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        bilgigr = this;
        addToFormEnvironment(Lit0, this);
        Object obj = this.events$Mnto$Mnregister;
        while (obj != LList.Empty) {
            try {
                Pair arg0 = (Pair) obj;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = lists.car.apply1(event$Mninfo);
                String obj2 = apply1 == null ? null : apply1.toString();
                Object apply12 = lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj2, apply12 == null ? null : apply12.toString());
                obj = arg0.getCdr();
            } catch (ClassCastException e) {
                throw new WrongType(e, "arg0", -2, obj);
            }
        }
        addToGlobalVars(Lit2, lambda$Fn1);
        bilgigr closureEnv = this;
        obj = lists.reverse(this.global$Mnvars$Mnto$Mncreate);
        while (obj != LList.Empty) {
            try {
                arg0 = (Pair) obj;
                Object var$Mnval = arg0.getCar();
                Object var = lists.car.apply1(var$Mnval);
                addToGlobalVarEnvironment((Symbol) var, Scheme.applyToArgs.apply1(lists.cadr.apply1(var$Mnval)));
                obj = arg0.getCdr();
            } catch (ClassCastException e2) {
                throw new WrongType(e2, "arg0", -2, obj);
            } catch (ClassCastException e22) {
                throw new WrongType(e22, "arg0", -2, obj);
            } catch (ClassCastException e222) {
                throw new WrongType(e222, "add-to-form-environment", 0, component$Mnname);
            } catch (ClassCastException e3) {
                throw new WrongType(e3, "lookup-in-form-environment", 0, apply1);
            } catch (ClassCastException e2222) {
                throw new WrongType(e2222, "arg0", -2, obj);
            } catch (ClassCastException e22222) {
                throw new WrongType(e22222, "arg0", -2, obj);
            } catch (ClassCastException e222222) {
                throw new WrongType(e222222, "add-to-global-var-environment", 0, var);
            } catch (ClassCastException e2222222) {
                throw new WrongType(e2222222, "arg0", -2, obj);
            } catch (YailRuntimeError exception2) {
                processException(exception2);
                return;
            }
        }
        obj = lists.reverse(this.form$Mndo$Mnafter$Mncreation);
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            misc.force(arg0.getCar());
            obj = arg0.getCdr();
        }
        LList component$Mndescriptors = lists.reverse(this.components$Mnto$Mncreate);
        closureEnv = this;
        obj = component$Mndescriptors;
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            Object component$Mninfo = arg0.getCar();
            Object component$Mnname = lists.caddr.apply1(component$Mninfo);
            lists.cadddr.apply1(component$Mninfo);
            Object component$Mnobject = Invoke.make.apply2(lists.cadr.apply1(component$Mninfo), lookupInFormEnvironment((Symbol) lists.car.apply1(component$Mninfo)));
            SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
            addToFormEnvironment((Symbol) component$Mnname, component$Mnobject);
            obj = arg0.getCdr();
        }
        obj = component$Mndescriptors;
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            component$Mninfo = arg0.getCar();
            lists.caddr.apply1(component$Mninfo);
            Boolean init$Mnthunk = lists.cadddr.apply1(component$Mninfo);
            if (init$Mnthunk != Boolean.FALSE) {
                Scheme.applyToArgs.apply1(init$Mnthunk);
            }
            obj = arg0.getCdr();
        }
        obj = component$Mndescriptors;
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            component$Mninfo = arg0.getCar();
            component$Mnname = lists.caddr.apply1(component$Mninfo);
            lists.cadddr.apply1(component$Mninfo);
            callInitialize(SlotGet.field.apply2(this, component$Mnname));
            obj = arg0.getCdr();
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Object car;
        LList symbols = LList.makeList(argsArray, 0);
        Procedure procedure = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Pair result = LList.Empty;
        Object arg0 = symbols;
        while (arg0 != LList.Empty) {
            try {
                Pair arg02 = (Pair) arg0;
                Object arg03 = arg02.getCdr();
                car = arg02.getCar();
                try {
                    result = Pair.make(misc.symbol$To$String((Symbol) car), result);
                    arg0 = arg03;
                } catch (ClassCastException e) {
                    throw new WrongType(e, "symbol->string", 1, car);
                }
            } catch (ClassCastException e2) {
                throw new WrongType(e2, "arg0", -2, arg0);
            }
        }
        car = procedure.apply2(moduleMethod, LList.reverseInPlace(result));
        try {
            return misc.string$To$Symbol((CharSequence) car);
        } catch (ClassCastException e3) {
            throw new WrongType(e3, "string->symbol", 1, car);
        }
    }

    static Object lambda2() {
        return null;
    }
}
